from django.apps import AppConfig


class RandomWordGeneratorAppConfig(AppConfig):
    name = 'random_word_generator_app'
